Known issues: <https://github.com/PredictiveEcology/Biomass_core/issues>

version 1.5.4
=============

## dependency changes


## new features
* Several speed ups. See: [PR #54](https://github.com/PredictiveEcology/Biomass_core/pull/54)

## bug fixes

